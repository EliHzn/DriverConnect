// C:\Users\eliha\firebase\webapp\src\menu-items\index.jsx
import dashboardGroup from './dashboardGroup';
import pages from './pages';

// ==============================|| MENU ITEMS ||============================== //

const menuItems = {
    items: [dashboardGroup, pages]
};

export default menuItems;
